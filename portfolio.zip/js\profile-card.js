(function () {
  'use strict';

  var ANIMATION_CONFIG = {
    INITIAL_DURATION: 1200,
    INITIAL_X_OFFSET: 70,
    INITIAL_Y_OFFSET: 60,
    DEVICE_BETA_OFFSET: 20,
    ENTER_TRANSITION_MS: 180
  };

  function clamp(v, min, max) {
    if (min === undefined) min = 0;
    if (max === undefined) max = 100;
    return Math.min(Math.max(v, min), max);
  }

  function round(v, precision) {
    if (precision === undefined) precision = 3;
    return parseFloat(v.toFixed(precision));
  }

  function adjust(v, fMin, fMax, tMin, tMax) {
    return round(tMin + ((tMax - tMin) * (v - fMin)) / (fMax - fMin));
  }

  function createTiltEngine(shellRef, wrapRef) {
    var rafId = null;
    var running = false;
    var lastTs = 0;
    var currentX = 0;
    var currentY = 0;
    var targetX = 0;
    var targetY = 0;
    var DEFAULT_TAU = 0.14;
    var INITIAL_TAU = 0.6;
    var initialUntil = 0;

    function setVarsFromXY(x, y) {
      var shell = shellRef;
      var wrap = wrapRef;
      if (!shell || !wrap) return;

      var width = shell.clientWidth || 1;
      var height = shell.clientHeight || 1;

      var percentX = clamp((100 / width) * x);
      var percentY = clamp((100 / height) * y);

      var centerX = percentX - 50;
      var centerY = percentY - 50;

      var properties = {
        '--pointer-x': percentX + '%',
        '--pointer-y': percentY + '%',
        '--background-x': adjust(percentX, 0, 100, 35, 65) + '%',
        '--background-y': adjust(percentY, 0, 100, 35, 65) + '%',
        '--pointer-from-center': clamp(Math.hypot(percentY - 50, percentX - 50) / 50, 0, 1),
        '--pointer-from-top': percentY / 100,
        '--pointer-from-left': percentX / 100,
        '--rotate-x': round(-(centerX / 5)) + 'deg',
        '--rotate-y': round(centerY / 4) + 'deg'
      };

      for (var k in properties) {
        wrap.style.setProperty(k, properties[k]);
      }
    }

    function step(ts) {
      if (!running) return;
      if (lastTs === 0) lastTs = ts;
      var dt = (ts - lastTs) / 1000;
      lastTs = ts;

      var tau = ts < initialUntil ? INITIAL_TAU : DEFAULT_TAU;
      var k = 1 - Math.exp(-dt / tau);

      currentX += (targetX - currentX) * k;
      currentY += (targetY - currentY) * k;

      setVarsFromXY(currentX, currentY);

      var stillFar = Math.abs(targetX - currentX) > 0.05 || Math.abs(targetY - currentY) > 0.05;

      if (stillFar || document.hasFocus()) {
        rafId = requestAnimationFrame(step);
      } else {
        running = false;
        lastTs = 0;
        if (rafId) {
          cancelAnimationFrame(rafId);
          rafId = null;
        }
      }
    }

    function start() {
      if (running) return;
      running = true;
      lastTs = 0;
      rafId = requestAnimationFrame(step);
    }

    return {
      setImmediate: function (x, y) {
        currentX = x;
        currentY = y;
        setVarsFromXY(currentX, currentY);
      },
      setTarget: function (x, y) {
        targetX = x;
        targetY = y;
        start();
      },
      toCenter: function () {
        var shell = shellRef;
        if (!shell) return;
        this.setTarget(shell.clientWidth / 2, shell.clientHeight / 2);
      },
      beginInitial: function (durationMs) {
        initialUntil = performance.now() + durationMs;
        start();
      },
      getCurrent: function () {
        return { x: currentX, y: currentY, tx: targetX, ty: targetY };
      },
      cancel: function () {
        if (rafId) cancelAnimationFrame(rafId);
        rafId = null;
        running = false;
        lastTs = 0;
      }
    };
  }

  function getOffsets(evt, el) {
    var rect = el.getBoundingClientRect();
    return { x: evt.clientX - rect.left, y: evt.clientY - rect.top };
  }

  function initProfileCard(wrapper) {
    var shell = wrapper.querySelector('.pc-card-shell');
    if (!shell) return;

    var tiltEngine = createTiltEngine(shell, wrapper);
    var enterTimerRef = null;
    var leaveRafRef = null;

    function handlePointerMove(event) {
      var offsets = getOffsets(event, shell);
      tiltEngine.setTarget(offsets.x, offsets.y);
    }

    function handlePointerEnter(event) {
      shell.classList.add('active');
      shell.classList.add('entering');
      if (enterTimerRef) window.clearTimeout(enterTimerRef);
      enterTimerRef = window.setTimeout(function () {
        shell.classList.remove('entering');
      }, ANIMATION_CONFIG.ENTER_TRANSITION_MS);

      var offsets = getOffsets(event, shell);
      tiltEngine.setTarget(offsets.x, offsets.y);
    }

    function handlePointerLeave() {
      tiltEngine.toCenter();

      function checkSettle() {
        var current = tiltEngine.getCurrent();
        var settled = Math.hypot(current.tx - current.x, current.ty - current.y) < 0.6;
        if (settled) {
          shell.classList.remove('active');
          leaveRafRef = null;
        } else {
          leaveRafRef = requestAnimationFrame(checkSettle);
        }
      }
      if (leaveRafRef) cancelAnimationFrame(leaveRafRef);
      leaveRafRef = requestAnimationFrame(checkSettle);
    }

    shell.addEventListener('pointerenter', handlePointerEnter);
    shell.addEventListener('pointermove', handlePointerMove);
    shell.addEventListener('pointerleave', handlePointerLeave);

    var initialX = (shell.clientWidth || 0) - ANIMATION_CONFIG.INITIAL_X_OFFSET;
    var initialY = ANIMATION_CONFIG.INITIAL_Y_OFFSET;
    tiltEngine.setImmediate(initialX, initialY);
    tiltEngine.toCenter();
    tiltEngine.beginInitial(ANIMATION_CONFIG.INITIAL_DURATION);

    return {
      destroy: function () {
        shell.removeEventListener('pointerenter', handlePointerEnter);
        shell.removeEventListener('pointermove', handlePointerMove);
        shell.removeEventListener('pointerleave', handlePointerLeave);
        if (enterTimerRef) window.clearTimeout(enterTimerRef);
        if (leaveRafRef) cancelAnimationFrame(leaveRafRef);
        tiltEngine.cancel();
        shell.classList.remove('entering');
      }
    };
  }

  window.ProfileCard = initProfileCard;
})();
