(function () {
  'use strict';

  function hexToVec3(hex) {
    var h = hex.replace('#', '');
    return [
      parseInt(h.slice(0, 2), 16) / 255,
      parseInt(h.slice(2, 4), 16) / 255,
      parseInt(h.slice(4, 6), 16) / 255
    ];
  }

  var vertexShader = [
    'attribute vec2 uv;',
    'attribute vec2 position;',
    'varying vec2 vUv;',
    'void main() {',
    '  vUv = uv;',
    '  gl_Position = vec4(position, 0, 1);',
    '}'
  ].join('\n');

  var fragmentShader = [
    'precision highp float;',
    '',
    'uniform float uTime;',
    'uniform vec3 uResolution;',
    'uniform float uSpeed;',
    'uniform float uInnerLines;',
    'uniform float uOuterLines;',
    'uniform float uWarpIntensity;',
    'uniform float uRotation;',
    'uniform float uEdgeFadeWidth;',
    'uniform float uColorCycleSpeed;',
    'uniform float uBrightness;',
    'uniform vec3 uColor1;',
    'uniform vec3 uColor2;',
    'uniform vec3 uColor3;',
    'uniform vec2 uMouse;',
    'uniform float uMouseInfluence;',
    'uniform bool uEnableMouse;',
    '',
    '#define HALF_PI 1.5707963',
    '',
    'float hashF(float n) {',
    '  return fract(sin(n * 127.1) * 43758.5453123);',
    '}',
    '',
    'float smoothNoise(float x) {',
    '  float i = floor(x);',
    '  float f = fract(x);',
    '  float u = f * f * (3.0 - 2.0 * f);',
    '  return mix(hashF(i), hashF(i + 1.0), u);',
    '}',
    '',
    'float displaceA(float coord, float t) {',
    '  float result = sin(coord * 2.123) * 0.2;',
    '  result += sin(coord * 3.234 + t * 4.345) * 0.1;',
    '  result += sin(coord * 0.589 + t * 0.934) * 0.5;',
    '  return result;',
    '}',
    '',
    'float displaceB(float coord, float t) {',
    '  float result = sin(coord * 1.345) * 0.3;',
    '  result += sin(coord * 2.734 + t * 3.345) * 0.2;',
    '  result += sin(coord * 0.189 + t * 0.934) * 0.3;',
    '  return result;',
    '}',
    '',
    'vec2 rotate2D(vec2 p, float angle) {',
    '  float c = cos(angle);',
    '  float s = sin(angle);',
    '  return vec2(p.x * c - p.y * s, p.x * s + p.y * c);',
    '}',
    '',
    'void main() {',
    '  vec2 coords = gl_FragCoord.xy / uResolution.xy;',
    '  coords = coords * 2.0 - 1.0;',
    '  coords = rotate2D(coords, uRotation);',
    '',
    '  float halfT = uTime * uSpeed * 0.5;',
    '  float fullT = uTime * uSpeed;',
    '',
    '  float mouseWarp = 0.0;',
    '  if (uEnableMouse) {',
    '    vec2 mPos = rotate2D(uMouse * 2.0 - 1.0, uRotation);',
    '    float mDist = length(coords - mPos);',
    '    mouseWarp = uMouseInfluence * exp(-mDist * mDist * 4.0);',
    '  }',
    '',
    '  float warpAx = coords.x + displaceA(coords.y, halfT) * uWarpIntensity + mouseWarp;',
    '  float warpAy = coords.y - displaceA(coords.x * cos(fullT) * 1.235, halfT) * uWarpIntensity;',
    '  float warpBx = coords.x + displaceB(coords.y, halfT) * uWarpIntensity + mouseWarp;',
    '  float warpBy = coords.y - displaceB(coords.x * sin(fullT) * 1.235, halfT) * uWarpIntensity;',
    '',
    '  vec2 fieldA = vec2(warpAx, warpAy);',
    '  vec2 fieldB = vec2(warpBx, warpBy);',
    '  vec2 blended = mix(fieldA, fieldB, mix(fieldA, fieldB, 0.5));',
    '',
    '  float fadeTop = smoothstep(uEdgeFadeWidth, uEdgeFadeWidth + 0.4, blended.y);',
    '  float fadeBottom = smoothstep(-uEdgeFadeWidth, -(uEdgeFadeWidth + 0.4), blended.y);',
    '  float vMask = 1.0 - max(fadeTop, fadeBottom);',
    '',
    '  float tileCount = mix(uOuterLines, uInnerLines, vMask);',
    '  float scaledY = blended.y * tileCount;',
    '  float nY = smoothNoise(abs(scaledY));',
    '',
    '  float ridge = pow(',
    '    step(abs(nY - blended.x) * 2.0, HALF_PI) * cos(2.0 * (nY - blended.x)),',
    '    5.0',
    '  );',
    '',
    '  float lines = 0.0;',
    '  for (float i = 1.0; i < 3.0; i += 1.0) {',
    '    lines += pow(max(fract(scaledY), fract(-scaledY)), i * 2.0);',
    '  }',
    '',
    '  float pattern = vMask * lines;',
    '',
    '  float cycleT = fullT * uColorCycleSpeed;',
    '  float rChannel = (pattern + lines * ridge) * (cos(blended.y + cycleT * 0.234) * 0.5 + 1.0);',
    '  float gChannel = (pattern + vMask * ridge) * (sin(blended.x + cycleT * 1.745) * 0.5 + 1.0);',
    '  float bChannel = (pattern + lines * ridge) * (cos(blended.x + cycleT * 0.534) * 0.5 + 1.0);',
    '',
    '  vec3 col = (rChannel * uColor1 + gChannel * uColor2 + bChannel * uColor3) * uBrightness;',
    '  float alpha = clamp(length(col), 0.0, 1.0);',
    '',
    '  gl_FragColor = vec4(col, alpha);',
    '}'
  ].join('\n');

  function createLineWaves(container, options) {
    options = options || {};
    var opts = {
      speed: options.speed != null ? options.speed : 0.3,
      innerLineCount: options.innerLineCount != null ? options.innerLineCount : 32.0,
      outerLineCount: options.outerLineCount != null ? options.outerLineCount : 36.0,
      warpIntensity: options.warpIntensity != null ? options.warpIntensity : 1.0,
      rotation: options.rotation != null ? options.rotation : -45,
      edgeFadeWidth: options.edgeFadeWidth != null ? options.edgeFadeWidth : 0.0,
      colorCycleSpeed: options.colorCycleSpeed != null ? options.colorCycleSpeed : 1.0,
      brightness: options.brightness != null ? options.brightness : 0.2,
      color1: options.color1 || '#ffffff',
      color2: options.color2 || '#ffffff',
      color3: options.color3 || '#ffffff',
      enableMouseInteraction: options.enableMouseInteraction !== false,
      mouseInfluence: options.mouseInfluence != null ? options.mouseInfluence : 2.0
    };

    function loadOGL() {
      return new Promise(function(resolve, reject) {
        if (window.OGL) {
          resolve(window.OGL);
          return;
        }
        var script = document.createElement('script');
        script.type = 'module';
        script.textContent = 'import * as OGL from "./js/ogl.min.js"; window.OGL = OGL; window.dispatchEvent(new Event("OGLLoaded"));';
        document.head.appendChild(script);
        
        window.addEventListener('OGLLoaded', function() {
          if (window.OGL) {
            resolve(window.OGL);
          } else {
            reject(new Error('OGL not loaded'));
          }
        });
        
        setTimeout(function() {
          if (!window.OGL) {
            reject(new Error('OGL load timeout'));
          }
        }, 5000);
      });
    }

    return loadOGL().then(function (OGL) {
      var Renderer = OGL.Renderer;
      var Program = OGL.Program;
      var Mesh = OGL.Mesh;
      var Triangle = OGL.Triangle;

      var renderer = new Renderer({ alpha: true, premultipliedAlpha: false, antialias: true });
      var gl = renderer.gl;
      gl.clearColor(0, 0, 0, 0);

      var program;
      var currentMouse = [0.5, 0.5];
      var targetMouse = [0.5, 0.5];

    function handleMouseMove(e) {
      var rect = gl.canvas.getBoundingClientRect();
      targetMouse = [
        (e.clientX - rect.left) / rect.width,
        1.0 - (e.clientY - rect.top) / rect.height
      ];
    }

    function handleMouseLeave() {
      targetMouse = [0.5, 0.5];
    }

    function resize() {
      renderer.setSize(container.offsetWidth, container.offsetHeight);
      if (program) {
        program.uniforms.uResolution.value = [gl.canvas.width, gl.canvas.height, gl.canvas.width / gl.canvas.height];
      }
    }
    window.addEventListener('resize', resize);

    var geometry = new Triangle(gl);
    var rotationRad = (opts.rotation * Math.PI) / 180;
    program = new Program(gl, {
      vertex: vertexShader,
      fragment: fragmentShader,
      uniforms: {
        uTime: { value: 0 },
        uResolution: { value: [gl.canvas.width, gl.canvas.height, gl.canvas.width / gl.canvas.height] },
        uSpeed: { value: opts.speed },
        uInnerLines: { value: opts.innerLineCount },
        uOuterLines: { value: opts.outerLineCount },
        uWarpIntensity: { value: opts.warpIntensity },
        uRotation: { value: rotationRad },
        uEdgeFadeWidth: { value: opts.edgeFadeWidth },
        uColorCycleSpeed: { value: opts.colorCycleSpeed },
        uBrightness: { value: opts.brightness },
        uColor1: { value: hexToVec3(opts.color1) },
        uColor2: { value: hexToVec3(opts.color2) },
        uColor3: { value: hexToVec3(opts.color3) },
        uMouse: { value: new Float32Array([0.5, 0.5]) },
        uMouseInfluence: { value: opts.mouseInfluence },
        uEnableMouse: { value: opts.enableMouseInteraction }
      }
    });

    var mesh = new Mesh(gl, { geometry: geometry, program: program });
    container.appendChild(gl.canvas);

    resize();

    if (opts.enableMouseInteraction) {
      gl.canvas.addEventListener('mousemove', handleMouseMove);
      gl.canvas.addEventListener('mouseleave', handleMouseLeave);
    }

    var animationFrameId;

    function update(time) {
      animationFrameId = requestAnimationFrame(update);
      program.uniforms.uTime.value = time * 0.001;

      if (opts.enableMouseInteraction) {
        currentMouse[0] += 0.05 * (targetMouse[0] - currentMouse[0]);
        currentMouse[1] += 0.05 * (targetMouse[1] - currentMouse[1]);
        program.uniforms.uMouse.value[0] = currentMouse[0];
        program.uniforms.uMouse.value[1] = currentMouse[1];
      } else {
        program.uniforms.uMouse.value[0] = 0.5;
        program.uniforms.uMouse.value[1] = 0.5;
      }

      renderer.render({ scene: mesh });
    }
    animationFrameId = requestAnimationFrame(update);

    return {
      destroy: function () {
        cancelAnimationFrame(animationFrameId);
        window.removeEventListener('resize', resize);
        if (opts.enableMouseInteraction) {
          gl.canvas.removeEventListener('mousemove', handleMouseMove);
          gl.canvas.removeEventListener('mouseleave', handleMouseLeave);
        }
        if (gl.canvas.parentNode) container.removeChild(gl.canvas);
        var loseExt = gl.getExtension('WEBGL_lose_context');
        if (loseExt) loseExt.loseContext();
      }
    };
    }).catch(function (err) {
      console.warn('LineWaves: failed to load ogl', err);
      return null;
    });
  }

  window.LineWaves = createLineWaves;
})();
