(function () {
  'use strict';

  function splitChars(el) {
    var text = el.textContent;
    el.textContent = '';
    var line = document.createElement('span');
    line.className = 'line';
    text.split('').forEach(function (ch, i) {
      if (ch === ' ' || ch === '\n') {
        line.appendChild(document.createTextNode(ch));
      } else {
        var s = document.createElement('span');
        s.className = 'char';
        s.textContent = ch;
        s.style.setProperty('--ci', i);
        line.appendChild(s);
      }
    });
    el.appendChild(line);
  }

  function splitLines(el) {
    var raw = el.textContent;
    el.textContent = '';
    raw.split('\n').forEach(function (lineText, li) {
      if (!lineText.trim()) return;
      var line = document.createElement('span');
      line.className = 'line';
      var ci = 0;
      lineText.split('').forEach(function (ch) {
        if (ch === ' ') {
          line.appendChild(document.createTextNode(' '));
        } else {
          var s = document.createElement('span');
          s.className = 'char';
          s.textContent = ch;
          s.style.setProperty('--ci', ci++);
          line.appendChild(s);
        }
      });
      el.appendChild(line);
    });
  }

  function splitLinesChars(el) {
    var raw = el.textContent;
    el.textContent = '';
    raw.split('\n').forEach(function (lineText) {
      if (!lineText.trim()) return;
      var line = document.createElement('span');
      line.className = 'line';
      var ci = 0;
      lineText.split('').forEach(function (ch) {
        if (ch === ' ') {
          line.appendChild(document.createTextNode(' '));
        } else {
          var s = document.createElement('span');
          s.className = 'char';
          s.textContent = ch;
          s.style.setProperty('--ci', ci++);
          line.appendChild(s);
        }
      });
      el.appendChild(line);
    });
  }

  var revealSelectors = [
    '.section-title',
    '.message-text',
    '.footer-tagline',
    '.entry-card h3'
  ].join(', ');

  function makeRevealUnit(textHTML) {
    var unit = document.createElement('span');
    unit.className = 'text-reveal-line';
    var inner = document.createElement('span');
    inner.className = 'text-reveal-text';
    inner.innerHTML = textHTML;
    var block = document.createElement('span');
    block.className = 'text-reveal-block';
    unit.appendChild(inner);
    unit.appendChild(block);
    return unit;
  }

  function wrapRevealText() {
    document.querySelectorAll(revealSelectors).forEach(function (el) {
      if (el.closest('.hero')) return;
      if (el.closest('.footer')) return;
      if (el.classList.contains('text-reveal')) return;
      if (el.querySelector('.text-reveal-text')) return;

      var hasBr = el.innerHTML.indexOf('<br>') !== -1 || el.innerHTML.indexOf('<br/>') !== -1 || el.innerHTML.indexOf('<br />') !== -1;

      if (hasBr) {
        var html = el.innerHTML.replace(/<br\s*\/?>/gi, '\n');
        var lines = html.split('\n').filter(function (l) { return l.trim() !== ''; });
        var frag = document.createDocumentFragment();
        lines.forEach(function (lineHTML) {
          frag.appendChild(makeRevealUnit(lineHTML));
        });
        el.innerHTML = '';
        el.classList.add('text-reveal-group');
        el.appendChild(frag);
      } else {
        var unit = makeRevealUnit(el.innerHTML);
        el.innerHTML = '';
        el.classList.add('text-reveal');
        el.appendChild(unit);
      }
    });
  }

  function applyAll() {
    document.querySelectorAll('[data-split]').forEach(function (el) {
      var mode = el.getAttribute('data-split');
      if (mode === 'chars') splitChars(el);
      else if (mode === 'lines') splitLines(el);
      else if (mode === 'lines,chars') splitLinesChars(el);
    });
    wrapRevealText();
  }

  window.SplitText = { applyAll: applyAll, wrapRevealText: wrapRevealText };
})();
