(function () {
  'use strict';

  function createScrollVelocity(container, options) {
    options = options || {};
    var texts = options.texts || [];
    var velocity = options.velocity || 100;
    var numCopies = options.numCopies || 6;
    var className = options.className || '';

    if (texts.length === 0) return;

    function wrap(min, max, v) {
      var range = max - min;
      var mod = (((v - min) % range) + range) % range;
      return mod + min;
    }

    texts.forEach(function (text, index) {
      var parallax = document.createElement('div');
      parallax.className = 'scroll-velocity-parallax ' + (index === 0 ? 'scroll-velocity-row-green' : 'scroll-velocity-row-outline') + (index % 2 !== 0 ? ' scroll-velocity-row-reverse' : '');

      var scroller = document.createElement('div');
      scroller.className = 'scroll-velocity-scroller ' + className;

      var copyRef = null;
      var copyWidth = 0;
      var baseX = 0;
      var baseVelocity = index % 2 !== 0 ? -velocity : velocity;
      var directionFactor = 1;
      var lastTime = null;

      for (var i = 0; i < numCopies; i++) {
        var span = document.createElement('span');
        span.textContent = text;
        if (i === 0) copyRef = span;
        scroller.appendChild(span);
      }

      parallax.appendChild(scroller);
      container.appendChild(parallax);

      function updateWidth() {
        if (copyRef) {
          copyWidth = copyRef.offsetWidth + 32;
        }
      }

      function animate(time) {
        if (lastTime === null) lastTime = time;
        var delta = Math.max(0, time - lastTime);
        lastTime = time;

        var moveBy = directionFactor * baseVelocity * (delta / 1000);
        baseX += moveBy;

        if (copyWidth > 0) {
          var wrappedX = wrap(-copyWidth, 0, baseX);
          scroller.style.transform = 'translateX(' + wrappedX + 'px)';
        }

        requestAnimationFrame(animate);
      }

      requestAnimationFrame(animate);
      window.addEventListener('resize', updateWidth);
      setTimeout(updateWidth, 100);
      setTimeout(updateWidth, 500);
    });
  }

  window.ScrollVelocity = createScrollVelocity;
})();
