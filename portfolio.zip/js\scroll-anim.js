(function () {
  'use strict';

  function init() {
    if (window.SplitText) window.SplitText.applyAll();

    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
    gsap.registerPlugin(ScrollTrigger);

    // ----- Reveal helpers via ScrollTrigger -----
    var revealEls = document.querySelectorAll('.reveal-up, .reveal-scale, .reveal-fade');
    revealEls.forEach(function (el) {
      gsap.fromTo(el,
        el.classList.contains('reveal-scale')
          ? { opacity: 0, scale: 0.9 }
          : el.classList.contains('reveal-fade')
            ? { opacity: 0 }
            : { opacity: 0, y: 60 },
        {
          opacity: 1, y: 0, scale: 1,
          duration: 0.9, ease: 'expo.out',
          scrollTrigger: { trigger: el, start: 'top 85%', once: true }
        });
    });

    // ----- Split text reveal (skip hero, triggered manually by preloader) -----
    document.querySelectorAll('.split-text').forEach(function (el) {
      if (el.closest('.hero')) return;
      ScrollTrigger.create({
        trigger: el,
        start: 'top 92%',
        once: true,
        onEnter: function () {
          el.classList.add('is-revealed');
        }
      });
    });

    // ----- Text reveal (grouped per section, staggered top-to-bottom 0.1s) -----
    var containers = document.querySelectorAll('section, footer');
    containers.forEach(function (container) {
      var items = container.querySelectorAll('.text-reveal, .text-reveal-line');
      if (!items.length) return;
      ScrollTrigger.create({
        trigger: container,
        start: 'top 88%',
        once: true,
        onEnter: function () {
          var order = Array.prototype.slice.call(items).sort(function (a, b) {
            return a.getBoundingClientRect().top - b.getBoundingClientRect().top;
          });
          order.forEach(function (el, idx) {
            el.style.setProperty('--stagger', (idx * 0.1) + 's');
            el.classList.add('is-revealed');
          });
        }
      });
    });

    // ----- Background blob parallax -----
    document.querySelectorAll('.bg-blob').forEach(function (blob) {
      var speed = blob.classList.contains('bg-blob-1') ? 80 : -60;
      gsap.to(blob, {
        yPercent: speed / 100,
        ease: 'none',
        scrollTrigger: {
          trigger: blob.closest('section') || blob.closest('footer'),
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1
        }
      });
    });

    // ----- Horizontal gallery pin -----
    var track = document.getElementById('galleryTrack');
    var pin = document.getElementById('gallery');
    var progress = document.getElementById('galleryProgress');
    if (track && pin) {
      var getDistance = function () {
        return track.scrollWidth - window.innerWidth;
      };
      ScrollTrigger.create({
        trigger: pin,
        start: 'top top',
        end: function () { return '+=' + getDistance(); },
        pin: true,
        scrub: 1,
        invalidateOnRefresh: true,
        onUpdate: function (self) {
          var d = getDistance();
          gsap.set(track, { x: -self.progress * d });
          if (progress) progress.style.width = (self.progress * 100) + '%';
        }
      });
    }

    // ----- Nav dots sync -----
    var dots = document.querySelectorAll('.dot');
    var sections = [];
    dots.forEach(function (d) {
      var s = document.getElementById(d.dataset.section);
      if (s) sections.push({ el: s, dot: d });
    });
    sections.forEach(function (item) {
      ScrollTrigger.create({
        trigger: item.el,
        start: 'top 50%',
        end: 'bottom 50%',
        onToggle: function (self) {
          if (self.isActive) {
            dots.forEach(function (d) { d.classList.remove('is-active'); });
            item.dot.classList.add('is-active');
          }
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
