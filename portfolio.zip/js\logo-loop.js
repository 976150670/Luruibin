(function () {
  'use strict';

  function createLogoLoop(container, options) {
    options = options || {};
    var logos = options.logos || [];
    var speed = options.speed || 60;
    var logoHeight = options.logoHeight || 48;
    var gap = options.gap || 60;

    var track = document.createElement('div');
    track.style.cssText = 'display:flex;align-items:center;width:max-content;will-change:transform;gap:' + gap + 'px;';

    function createItem(item) {
      var el = document.createElement('div');
      el.style.cssText = 'flex:0 0 auto;display:flex;align-items:center;transition:transform 0.3s;';
      var img = document.createElement('img');
      img.src = item.src;
      img.alt = item.alt || '';
      img.style.cssText = 'height:' + logoHeight + 'px;width:auto;display:block;filter:grayscale(1);opacity:0.6;transition:filter 0.3s,opacity 0.3s;';
      img.draggable = false;
      el.appendChild(img);
      el.addEventListener('mouseenter', function () { img.style.filter = 'grayscale(0)'; img.style.opacity = '1'; });
      el.addEventListener('mouseleave', function () { img.style.filter = 'grayscale(1)'; img.style.opacity = '0.6'; });
      return el;
    }

    for (var i = 0; i < 3; i++) {
      for (var j = 0; j < logos.length; j++) {
        track.appendChild(createItem(logos[j]));
      }
    }

    container.style.overflow = 'hidden';
    container.appendChild(track);

    var offset = 0;
    var lastTime = null;

    function animate(time) {
      if (lastTime === null) lastTime = time;
      var dt = (time - lastTime) / 1000;
      lastTime = time;
      offset += speed * dt;
      var trackWidth = track.scrollWidth / 3;
      if (offset >= trackWidth) offset -= trackWidth;
      track.style.transform = 'translateX(' + (-offset) + 'px)';
      requestAnimationFrame(animate);
    }

    requestAnimationFrame(animate);
  }

  window.LogoLoop = createLogoLoop;
})();
