﻿document.addEventListener('DOMContentLoaded', function () {

  // ===== Lenis smooth scroll =====
  var lenis = null;
  if (typeof Lenis !== 'undefined') {
    lenis = new Lenis({
      duration: 1.1,
      easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); },
      smoothWheel: true
    });
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(function (time) { lenis.raf(time * 1000); });
      gsap.ticker.lagSmoothing(0);
    } else {
      function raf(time) {
        lenis.raf(time);
        requestAnimationFrame(raf);
      }
      requestAnimationFrame(raf);
    }
  }

  // ===== Preloader (auto enter — site expands outward from LOGO center) =====
  var preloader = document.getElementById('preloader');
  var siteRoot = document.getElementById('siteRoot');
  if (preloader) {
    if (lenis) lenis.stop();
    document.body.style.overflow = 'hidden';

    function revealHeroText() {
      var heroSplits = document.querySelectorAll('.hero .split-text');
      heroSplits.forEach(function (el, lineIdx) {
        el.classList.add('is-revealed');
        el.querySelectorAll('.char').forEach(function (c) {
          var ci = parseInt(c.style.getPropertyValue('--ci') || '0', 10);
          c.style.transitionDelay = (lineIdx * 0.08 + ci * 0.03) + 's';
        });
      });
    }

    function closePreloader() {
      if (siteRoot) {
        revealHeroText();
        siteRoot.classList.add('is-open');
        preloader.classList.add('is-done');
        var done = false;
        function finish() {
          if (done) return; done = true;
          preloader.style.display = 'none';
          document.body.style.overflow = '';
          if (lenis) lenis.start();
          if (typeof ScrollTrigger !== 'undefined') setTimeout(function () { ScrollTrigger.refresh(); }, 100);
        }
        siteRoot.addEventListener('transitionend', function (e) {
          if (e.propertyName === 'clip-path') finish();
        });
        setTimeout(finish, 1600);
      } else {
        preloader.classList.add('is-done');
        setTimeout(function () {
          preloader.style.display = 'none';
        }, 300);
        document.body.style.overflow = '';
        if (lenis) lenis.start();
        revealHeroText();
      }
    }

    // rect draw 1.1s + text in 0.9s (starts at 0.9s) = done ~1.5s, then expand outward
    setTimeout(closePreloader, 1700);
  }

  // ===== Menu =====
  var menuToggle = document.getElementById('menuToggle');
  var menuOverlay = document.getElementById('menuOverlay');
  if (menuToggle && menuOverlay) {
    menuToggle.addEventListener('click', function () {
      menuToggle.classList.toggle('is-open');
      menuOverlay.classList.toggle('is-open');
    });
    menuOverlay.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        menuToggle.classList.remove('is-open');
        menuOverlay.classList.remove('is-open');
      });
    });
  }

  // ===== Dot navigation =====
  document.querySelectorAll('.dot').forEach(function (dot) {
    dot.addEventListener('click', function (e) {
      e.preventDefault();
      var target = document.getElementById(dot.dataset.section);
      if (!target) return;
      if (lenis) lenis.scrollTo(target, { offset: 0 });
      else target.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // ===== Stagger delays =====
  document.querySelectorAll('.showcase-card').forEach(function (el, i) { el.style.transitionDelay = (i * 0.08) + 's'; });
  document.querySelectorAll('.social-tile').forEach(function (el, i) { el.style.transitionDelay = (i * 0.06) + 's'; });
  document.querySelectorAll('.entry-card').forEach(function (el, i) { el.style.transitionDelay = (i * 0.12) + 's'; });

  // ===== Scroll hint hide =====
  var hint = document.querySelector('.scroll-hint');
  var scrolled = false;
  window.addEventListener('scroll', function () {
    if (!scrolled && window.scrollY > 80 && hint) {
      scrolled = true;
      hint.style.opacity = '0';
      hint.style.transition = 'opacity 0.5s ease';
    }
  });

  // ===== LineWaves (WebGL wave animation background) =====
  var lineWavesContainer = document.getElementById('lineWaves');
  if (lineWavesContainer && window.LineWaves) {
    window.LineWaves(lineWavesContainer, {
      speed: 0.4,
      innerLineCount: 6,
      outerLineCount: 31,
      warpIntensity: 0.8,
      rotation: -121,
      edgeFadeWidth: 0.1,
      colorCycleSpeed: 1.0,
      brightness: 0.1,
      color1: '#84CC16',
      color2: '#a7ee3c',
      color3: '#ffffff',
      enableMouseInteraction: true,
      mouseInfluence: 2.0
    }).then(function (instance) {
      if (instance) console.log('LineWaves started');
    });
  }

  // ===== LogoLoop (partner logos infinite scroll) =====
  var partnerLogos = [
    { src: 'assets/svg/logos/openai-light.svg', alt: 'OpenAI' },
    { src: 'assets/svg/logos/codex-openai.svg', alt: 'Codex' },
    { src: 'assets/svg/logos/maya.svg', alt: 'Maya' },
    { src: 'assets/svg/logos/godot.svg', alt: 'Godot' },
    { src: 'assets/svg/logos/unreal-engine-mono.svg', alt: 'Unreal Engine' },
    { src: 'assets/svg/logos/blender.svg', alt: 'Blender' },
    { src: 'assets/svg/logos/github.svg', alt: 'GitHub' },
    { src: 'assets/svg/logos/photoshop.svg', alt: 'Photoshop' },
    { src: 'assets/svg/logos/lightroom-classic.svg', alt: 'Lightroom' },
    { src: 'assets/svg/logos/premierepro.svg', alt: 'Premiere Pro' },
    { src: 'assets/svg/logos/capcut.svg', alt: 'CapCut' },
    { src: 'assets/svg/logos/nikon.svg', alt: 'Nikon' }
  ];

  var lp1 = document.getElementById('logoLoop1');
  if (lp1 && window.LogoLoop) {
    window.LogoLoop(lp1, {
      logos: partnerLogos,
      speed: 60,
      logoHeight: 48,
      gap: 120
    });
  }

  // ===== ProfileCard (3D tilt effect) =====
  var profileCard = document.getElementById('profileCard');
  if (profileCard && window.ProfileCard) {
    window.ProfileCard(profileCard);
  }

  // ===== ScrollVelocity (scroll-based text animation) =====
  var scrollVelocity = document.getElementById('scrollVelocity');
  if (scrollVelocity && window.ScrollVelocity) {
    window.ScrollVelocity(scrollVelocity, {
      texts: ['RIVEN LU', 'CREATIVE DESIGNER'],
      velocity: 30,
      numCopies: 8
    });
  }
});
